package com.example.finalproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_second.*
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.util.*

class SecondActivity : AppCompatActivity() {

    //Variables
    lateinit var userGuess: TextView
    lateinit var guessBtn: Button
    lateinit var nextBtn: Button
    lateinit var randomGreek: TextView
    lateinit var god:String
    lateinit var random:Random
    //Array
    internal var greekGods = arrayOf(
        "Aphrodite", "Apollo", "Ares", "Artemis", "Athena", "Demeter", "Dionysus", "Hephaestus", "Hera", "Hermes", "Poseidon", "Hades", "Zeus", "Hestia"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        //Initialize Variables
        userGuess = findViewById(R.id.userGuess)
        guessBtn = findViewById(R.id.guessBtn)
        nextBtn = findViewById(R.id.nextBtn)
        randomGreek = findViewById(R.id.randomGreek)
        random = Random()

        god = greekGods[random.nextInt(greekGods.size)]
        randomGreek.text = mixWords(god)

        //Guess Button
        guessBtn.setOnClickListener{
            if (userGuess.text.toString().equals(god,ignoreCase = true)){
                Toast.makeText(this@SecondActivity,"You Got It!", Toast.LENGTH_SHORT).show()
            }
            else{
                Toast.makeText(this@SecondActivity,"Try Again", Toast.LENGTH_SHORT).show()
            }
        }

        //Next Button
        nextBtn.setOnClickListener{
            god = greekGods[random.nextInt(greekGods.size)]
            randomGreek.text = mixWords(god)

            userGuess.setText("")
        }
    }

    //Randomize the Array Words
    fun mixWords(word:String) : String{
        val word = Arrays.asList<String>(*word.split("".toRegex()).dropLastWhile({it.isEmpty()}).toTypedArray())

        Collections.shuffle(word)
        var mixed = ""

        for(i in word){
            mixed += i
        }
        return mixed
    }

    //Navigation Buttons
    fun helpPage(view: View) {
        var intent = Intent(this, FourthActivity::class.java)
        startActivity(intent)
    }

    fun settingsPage(view: View) {
        var intent = Intent(this, ThirdActivity::class.java)
        startActivity(intent)
    }

    fun homePage(view: View) {
        var intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}