package com.example.finalproject

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_third.*

class ThirdActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)

        loadData()

        saveBtn.setOnClickListener{
            saveData()
        }
    }
    //Function to save settings from the user
    private fun saveData(){
        val insertedText = userName.text.toString()
        usernameText.text = insertedText

        val sharedPreferences = getSharedPreferences("sharedPref", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.apply{
            putString("STRING_KEY", insertedText)

        }.apply()

        Toast.makeText(this, "Data Saved", Toast.LENGTH_SHORT).show()
    }
    //Function to load settings made by the user
    private fun loadData(){
        val sharedPreferences = getSharedPreferences("sharedPref", Context.MODE_PRIVATE)
        val savedString = sharedPreferences.getString("STRING_KEY", null)

        usernameText.text = savedString
    }

    //Navigation Buttons
    fun helpPage(view: View) {
        var intent = Intent(this, FourthActivity::class.java)
        startActivity(intent)
    }

    fun homePage(view: View) {
        var intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}